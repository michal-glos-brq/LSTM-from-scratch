"""
This file implements a neural network model with 2 linear layers - first with activation ReLU,
the second is None. This model works like rough regressor/estimator, final values have to be rounded
for integer ranking eventually when evaluating (decimals provide good gradients when learning)
"""

import torch

from LSTM.utils import sigmoid_d


class Regressor:
    """
    Simple dense neural network to process LSTM features into a predicted value

    Manually programmed backpropagation results in possibl only one last batch being
    used for training, as previous batch process data would be overwritten by the new one
    """

    def __init__(self, input_size, hidden_size, device="cpu", torch_type=torch.float32):
        """Initialize the regression model"""
        self.torch_type = torch_type
        self.W1 = torch.nn.init.xavier_uniform_(
            torch.empty((input_size, hidden_size), requires_grad=False, device=device, dtype=self.torch_type)
        )
        self.W2 = torch.nn.init.xavier_uniform_(
            torch.empty((hidden_size, 1), requires_grad=False, device=device, dtype=self.torch_type)
        )
        self.b1 = torch.zeros((hidden_size,), requires_grad=False, device=device, dtype=self.torch_type)
        self.b2 = torch.zeros((1,), requires_grad=False, device=device, dtype=self.torch_type)

    def forward(self, X, requires_grad=True):
        """
        Forward pass with 2 layered regressor

        X (torch.Tensor) : Input tensor of shape (batch_size, input_size)
        """
        hidden_output = torch.sigmoid(torch.matmul(X, self.W1) + self.b1)
        output = torch.matmul(hidden_output, self.W2) + self.b2

        # Keep data for gradient computation
        if requires_grad:
            self.X = X
            self.hidden_output = hidden_output

        return output

    def backward(self, loss_d, lr):
        """
        Perform backward pass and apply gradients

        Args:
            loss_d (torch.Tensor): Chained derivative of objective function of shape (batch_size, 1)
            lr (float): Learning rate
        """
        # loss_d is actually chained gradient, derivative of MSE and activation function, which is None
        hidden_layer_loss = torch.matmul(loss_d, self.W2.T)
        hidden_layer_chain_d = hidden_layer_loss * sigmoid_d(self.hidden_output)

        # Update weights and biases
        dW2 = torch.matmul(self.hidden_output.T, loss_d) * lr
        db2 = torch.sum(loss_d, dim=0) * lr  # Sum over batches

        # We use lr as limits because it's a faster way on how to apply the clamping after multiplying with learning rate
        self.W2 += torch.clip(dW2, min=-lr, max=lr)
        self.b2 += torch.clip(db2, min=-lr, max=lr)

        dW1 = torch.matmul(self.X.T, hidden_layer_chain_d) * lr
        db1 = torch.sum(hidden_layer_chain_d, dim=0) * lr  # Sum over batches
        self.W1 += torch.clip(dW1, min=-lr, max=lr)
        self.b1 += torch.clip(db1, min=-lr, max=lr)

        # Return chained derivatives for layers before the classifier
        out_chain_d = torch.matmul(hidden_layer_chain_d, self.W1.T)
        return out_chain_d


"""
This is dummy training example for the regressor, could be used later

r = Regressor(10,6)
y = torch.randint(0,10, (10000,))
X = torch.zeros((10000, 10))
X[torch.arange(10000), y] = 1

def train_vec(X, y, lr, step):
    losses, correct = [], []
    for i in range(0, len(X), step):
        x = X[i:i+step]
        _y = y[i:i+step].unsqueeze(1)
        y_pred = r.forward(x)
        loss = mse_loss(_y, y_pred)
        losses.append(loss)
        c = (torch.round(y_pred) == _y).sum() / len(y_pred)
        correct.append(c)
        loss_d = mse_loss_d(_y, y_pred)
        r.backward(loss_d, lr)
    print(f"l: {sum(losses) / len(losses)}; c: {100 * sum(correct) / len(correct)} %")

for i in range(100):
    train_vec(X, y, 0.03, 16)
    
    
# This works with the whole LSTM    
    
    from tqdm import tqdm
epochs = 1000
batch = 128

losses = []
pbar = tqdm(range(epochs), desc=f'Training ... loss: {0.0}')

for epoch in pbar:
    for i in range(0, X.shape[0], batch):
        x = X[i:i+batch]
        y_gt = y[i:i+batch].unsqueeze(1)
        hidden_states = cell.forward(x)
        # Obtain the last hidden states to be fed to the regressor
        last_hidden_states = hidden_states[:, -1, :]
        y_pred = regressor.forward(last_hidden_states)

        # Calculate losses
        loss = mse_loss(y_gt, y_pred)
        loss_d = mse_loss_d(y_gt, y_pred)

        # Backward
        chained_d = regressor.backward(loss_d, 1/batch)
        # Now it goes (sequence_len, batch_size, vector_size)
        chained_ds = torch.zeros((x.shape[1], *chained_d.shape))
        chained_ds[-1] = chained_d
        chained_ds = chained_ds.transpose(1,0)
        
        c_state_d, h_state_d, input_d = cell.backward(chained_ds, 0.5/batch)
    
        losses.append(loss.item())
    
        if ((i/batch) % 10) == 9:
            pbar.set_description(f'Training ... loss: {sum(losses[-64:]) / len(losses[-64:])}')

    
    

"""
