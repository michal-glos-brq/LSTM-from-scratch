"""
This file implements simple LSTM cell implementation with BTT.
The cell is capable of processing a batch of heterogenous input vectors, one at a time.
Also implements BTT, no gradient cumulation over several batches possible.
"""
import torch

from LSTM.utils import LSTMGradParams, LSTMGrads, sigmoid_d, tanh_d


class LSTMCell:
    """
    A full LSTM cell implementation, handling heterogenous sequences in a batch with zero padding.
    """

    def __init__(self, input_size, hidden_size, device="cpu", torch_type=torch.float32):
        """
        Initialize the class

        Args:
            input_size (int): Cell input length
            hidden_size (int): Size of the hidden state vector
            device (str): Device to work on (GPU/CPU) or rather (cpu/cuda)
        """
        self.hidden_size, self.inpu_size = hidden_size, input_size
        self.device, self.torch_type = device, torch_type
        # Initialize zero with zeros of shape (batch_size, hidden_size) as initial states
        self.init_cell_state = torch.zeros((1, hidden_size), requires_grad=False, device=device)
        self.init_hidden_state = torch.zeros((1, hidden_size), requires_grad=False, device=device)

        # Init forget gate
        self.Wf = torch.nn.init.xavier_uniform_(
            torch.empty(input_size + hidden_size, hidden_size, requires_grad=False, device=device)
        )
        self.bf = torch.zeros((1, hidden_size), requires_grad=False, device=device)
        # Init input gate
        self.Wi = torch.nn.init.xavier_uniform_(
            torch.empty(input_size + hidden_size, hidden_size, requires_grad=False, device=device)
        )
        self.bi = torch.zeros((1, hidden_size), requires_grad=False, device=device)
        # Init output gate
        self.Wo = torch.nn.init.xavier_uniform_(
            torch.empty(input_size + hidden_size, hidden_size, requires_grad=False, device=device)
        )
        self.bo = torch.zeros((1, hidden_size), requires_grad=False, device=device)
        # Init candidate state gate
        self.Wc = torch.nn.init.xavier_uniform_(
            torch.empty(input_size + hidden_size, hidden_size, requires_grad=False, device=device)
        )
        self.bc = torch.zeros((1, hidden_size), requires_grad=False, device=device)

        # Initialize memory stack for gradient computation (BPTT) and gradient cumulation object
        self.memory = LSTMGradParams()
        self.grads = LSTMGrads(input_size, hidden_size, device=self.device)

    def apply_grads(self, lr):
        """
        Apply cumulated gradients through sequence to weights and biases.

        Args:
            lr (float): Learning rate
        """
        # We use lr as limits because it's a faster way on how to apply the clamping after multiplying with learning rate
        self.Wf -= torch.clamp(self.grads.dWf * lr, min=-lr, max=lr)
        self.bf -= torch.clamp(self.grads.dbf * lr, min=-lr, max=lr)
        self.Wi -= torch.clamp(self.grads.dWi * lr, min=-lr, max=lr)
        self.bi -= torch.clamp(self.grads.dbi * lr, min=-lr, max=lr)
        self.Wo -= torch.clamp(self.grads.dWo * lr, min=-lr, max=lr)
        self.bo -= torch.clamp(self.grads.dbo * lr, min=-lr, max=lr)
        self.Wc -= torch.clamp(self.grads.dWc * lr, min=-lr, max=lr)
        self.bc -= torch.clamp(self.grads.dbc * lr, min=-lr, max=lr)
        self.grads.zero_grad()

    def apply_init_state_grads(self, h_state_chained_d, c_state_chained_d, lr):
        """
        Apply gradients on initial hidden and cell state tensors,
        both gradients have the same size as initial states themselves - (hidden_state, )

        Args:
            h_state_chained_d (torch.Tensor): Tensor with gradients for the inti. hidden state
            c_state_chained_d (torch.Tensor): Tensor with gradients for the inti. cell state
        """
        # Sum over batch and apply gradient descent to the intial state tensors
        init_h_state_grad = torch.sum(h_state_chained_d, dim=0)
        init_c_state_grad = torch.sum(c_state_chained_d, dim=0)
        self.init_hidden_state -= torch.clamp(init_h_state_grad * lr, min=-lr, max=lr)
        self.init_cell_state -= torch.clamp(init_c_state_grad * lr, min=-lr, max=lr)

    def forward_step(self, x, cell_state_in, hidden_state_in, requires_grad=True):
        """
        Perform single step forward

        Args:
            x (torch.Tensor): Input fot the one step, shape: (batch_size, input_size)
            cell_state_in (torch.Tensor): cell_state from previous timestamp of shape (batch_size, hidden_state_size)
            hidden_state_in (torch.Tensor): hidden_state from previous timestamp of shape (batch_size, hidden_state_size)
            requires_grad (bool): Keep track of tensor flow in order to compute gradients and apply gradient descent

        Returns: torch.Tensor of shape (batch_size, vector_size)
        """
        cat_input = torch.column_stack((hidden_state_in, x))
        forget_gate = torch.sigmoid(torch.matmul(cat_input, self.Wf) + self.bf)
        input_gate = torch.sigmoid(torch.matmul(cat_input, self.Wi) + self.bi)
        output_gate = torch.sigmoid(torch.matmul(cat_input, self.Wo) + self.bo)
        candidate_gate = torch.tanh(torch.matmul(cat_input, self.Wc) + self.bc)

        cell_state = forget_gate * cell_state_in + input_gate * candidate_gate
        hidden_state = output_gate * torch.tanh(cell_state)

        if requires_grad:
            self.memory.add_entry(
                cat_input, cell_state_in, cell_state, input_gate, output_gate, forget_gate, candidate_gate
            )

        return hidden_state, cell_state

    def forward(self, X, requires_grad=True):
        """
        Inference of batched input sequences

        Args:
            X (torch.Tensor) : (batch_size, sequence_len, sequence_element_size)
        Returns: (torch.Tensor) : (batch_size, sequence_len, hidden_state_size)
        """
        # Clear gradient computation metadata
        self.memory.clear()
        # Initialize initial hidden and cell state values. Only vectors are allowed, hence
        # repeat is parametrized only for batch and single input dimenstions
        batch_size = X.shape[0]
        hidden_state = self.init_hidden_state.repeat(batch_size, 1)
        cell_state = self.init_cell_state.repeat(batch_size, 1)

        # Collect hidden states for output
        hidden_states = []
        # Transpose tensor so we iterate over sequences, not the batch
        for x in X.transpose(1, 0):
            hidden_state, cell_state = self.forward_step(x, cell_state, hidden_state, requires_grad=requires_grad)
            hidden_states.append(hidden_state)

        # Let's transpose it back to the original shape
        return torch.stack(hidden_states).transpose(1, 0)

    def backward_step(self, cell_state_d_in, hidden_state_d_in, cell_output_d_in):
        """
        Perform one backward step of gradient descent, cumulate gradients


        """
        # Invoke the tensors from memory stack
        cat_input = self.memory.cat_inputs.pop()
        cell_state_out = self.memory.cell_states_out.pop()
        cell_state_in = self.memory.cell_states_in.pop()

        candidate_gate = self.memory.candidate_gates.pop()
        output_gate = self.memory.output_gates.pop()
        forget_gate = self.memory.forget_gates.pop()
        input_gate = self.memory.input_gates.pop()

        self.memory.stack_size -= 1

        # Compute the state gradients
        hidden_state_d = hidden_state_d_in + cell_output_d_in
        cell_state_d = tanh_d(cell_state_out) * output_gate * hidden_state_d + cell_state_d_in
        # Computa candidate state gate gradients
        candidate_gate_d = cell_state_d * input_gate * tanh_d(candidate_gate)
        # Compute other state gradients
        forget_gate_d = candidate_gate_d * cell_state_in * sigmoid_d(forget_gate)
        output_gate_d = torch.tanh(cell_state_out) * hidden_state_d * sigmoid_d(output_gate)
        input_gate_d = cell_state_d * candidate_gate * sigmoid_d(input_gate)

        # Cumulate gradients (scaled by learning rate when applying gradients)
        self.grads.dWf -= torch.matmul(cat_input.T, forget_gate_d)
        self.grads.dbf -= torch.sum(forget_gate_d, dim=0)
        self.grads.dWi -= torch.matmul(cat_input.T, input_gate_d)
        self.grads.dbi -= torch.sum(input_gate_d, dim=0)
        self.grads.dWo -= torch.matmul(cat_input.T, output_gate_d)
        self.grads.dbo -= torch.sum(output_gate_d, dim=0)
        self.grads.dWc -= torch.matmul(cat_input.T, candidate_gate_d)
        self.grads.dbc -= torch.sum(candidate_gate_d, dim=0)

        # Derivative of concatenated vectors of LSTM input and hidden_state_in (will be split further)
        combined_gate_gradients = (
            torch.matmul(forget_gate_d, self.Wf.T),
            torch.matmul(candidate_gate_d, self.Wc.T),
            torch.matmul(input_gate_d, self.Wi.T),
            torch.matmul(output_gate_d, self.Wo.T),
        )
        bottom_chain_d = sum(combined_gate_gradients)

        # Now calculate the chained derivative for LSTM input (X)
        # and it's hidden and cell state derivatives for previous timestep
        cell_state_chain_d = forget_gate * cell_state_d
        input_chain_d = bottom_chain_d[:, self.hidden_size :]
        hidden_state_chain_d = bottom_chain_d[:, : self.hidden_size]

        # Return chained derivatives for backpropagation through time and layesr
        # Tuple:
        ## - chained derivative for cell state from t-1
        ## - chained derivative for hidden state from t-1
        ## - chained derivative for cell input from t
        return cell_state_chain_d, hidden_state_chain_d, input_chain_d

    def backward(self, hidden_states_d_in, lr):
        """
        Perform backpropagation through time
        Args:
            hidden_states_d_in (List[torch.Tensor]) : chained derivative from the output of shape (batch_size, hidden_size)
            lr (float) : learning rate
        """
        assert self.memory.stack_size == hidden_states_d_in.shape[1]
        self.grads.zero_grad()

        cell_state_d = torch.zeros_like(
            hidden_states_d_in[:, 0, :], requires_grad=False, device=self.device, dtype=self.torch_type
        )
        hidden_state_d = torch.zeros_like(
            hidden_states_d_in[:, 0, :], requires_grad=False, device=self.device, dtype=self.torch_type
        )

        # Collect derivatives
        input_derivatives = []
        h_state_derivatives = []
        c_state_derivatives = []

        # Do the backward steps
        # Here we swap batch and sequence length in order to iterate through sequences a reverse the sequence (we go backward)
        hidden_states_d_in = torch.flip(hidden_states_d_in, [1]).transpose(1, 0)

        for hidden_states_d in hidden_states_d_in:
            cell_state_d, hidden_state_d, input_chained_d = self.backward_step(
                cell_state_d, hidden_state_d, hidden_states_d
            )
            input_derivatives.append(input_chained_d)
            c_state_derivatives.append(cell_state_d)
            h_state_derivatives.append(hidden_state_d)

        # Pass there the last chained derivatives
        self.apply_init_state_grads(h_state_derivatives[-1], c_state_derivatives[-1], lr)
        self.apply_grads(lr)

        return (
            torch.stack(c_state_derivatives),
            torch.stack(h_state_derivatives),
            torch.stack(input_derivatives),
        )
