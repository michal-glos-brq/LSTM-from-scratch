import os
import sys
import gzip
import json
import logging
import requests

import nltk
from nltk import word_tokenize
from gensim.models import Word2Vec
from tqdm import tqdm

import torch
import numpy as np

from datasets.dataset import DatasetBase

# WOW:
# https://datajenius.com/2022/03/13/a-deep-dive-into-nlp-tokenization-encoding-word-embeddings-sentence-embeddings-word2vec-bert/

# Datasets with category as key and url as values
BASE_URL = "https://datarepo.eng.ucsd.edu/mcauley_group/data/amazon_v2/categoryFiles"
DATASETS = {
    "Fashion": "AMAZON_FASHION.json.gz",
    "Beauty": "All_Beauty.json.gz",
    "Appliances": "Appliances.json.gz",
    "Arts": "Arts_Crafts_and_Sewing.json.gz",
    "Automotive": "Automotive.json.gz",
    "Books": "Books.json.gz",
    "CDs": "CDs_and_Vinyl.json.gz",
    "Phones": "Cell_Phones_and_Accessories.json.gz",
    "Clothing": "Clothing_Shoes_and_Jewelry.json.gz",
    "Music": "Digital_Music.json.gz",
    "Electronics": "Electronics.json.gz",
    "GiftCards": "Gift_Cards.json.gz",
    "Groceries": "Grocery_and_Gourmet_Food.json.gz",
    "HomeKitchen": "Home_and_Kitchen.json.gz",
    "IndustrialScientific": "Industrial_and_Scientific.json.gz",
    "Kindle": "Kindle_Store.json.gz",
    "LuxuryBeauty": "Luxury_Beauty.json.gz",
    "Magazines": "Magazine_Subscriptions.json.gz",
    "Movies": "Movies_and_TV.json.gz",
    "MusicalInstruments": "Musical_Instruments.json.gz",
    "Office": "Office_Products.json.gz",
    "PatioGarden": "Patio_Lawn_and_Garden.json.gz",
    "Pets": "Pet_Supplies.json.gz",
    "PrimePantry": "Prime_Pantry.json.gz",
    "Software": "Software.json.gz",
    "Sports": "Sports_and_Outdoors.json.gz",
    "Tools": "Tools_and_Home_Improvement.json.gz",
    "Toys": "Toys_and_Games.json.gz",
    "VideoGames": "Video_Games.json.gz",
}


DATASET_OF_INTEREST = [
    "Magazines",
]


class AmazonDataset(DatasetBase):
    """
    Dataset class for Amazon product reviews

    This class implements:
        Selecting different subsets of dataset based on product category
        Downloads data directly from internet
        Loads data into desired torch datasets

    All data are obtained during object initialization, download included.
    Filesystem is checked if datasets are downloaede, if some or all are missing,
    download sequence is initiated and the data are then loaded from gzip files.
    After the embedding model is loaded and applied on all data. Finally, data
    are cut into maximum len. and padded with zeros to homogene lenghts.
    """

    def __init__(
        self, data_folder, device, torch_type, fragments=DATASET_OF_INTEREST, verified=False, embedding_size=64
    ):
        """
        Instantiate self, include dataset fragments included in the global var DATASET_OF_INTEREST

        Args:
            data_folder (str): A path to store the downloaded dataset fragments
            embedding_size (int): Length of embed vector (token)
            fragments  (List[str]): List of fragments of interest (Keys from DATASETS list)
            verified (bool): Keep verified attribute of data
        """
        super().__init__(torch_type, device)

        # Just obtain neccessary classes
        self.torch_factory = torch.cuda if device == "cuda" else torch
        if torch_type == torch.float16:
            self.tensor_factory = self.torch_factory.HalfTensor
        elif torch_type == torch.float32:
            self.tensor_factory = self.torch_factory.FloatTensor
        if torch_type == torch.float64:
            self.tensor_factory = self.torch_factory.DoubleTensor

        # Ensure some packages needed for runtime are installed
        nltk.download("punkt")

        self.embedding_size = embedding_size
        self.raw_data, self.formatted_data = [], []
        self.fragments = fragments
        self.data_folder = data_folder

        # Get the attributes we care about from the entries
        self.attributes_of_interest = ["overall", "reviewText"]
        if verified:
            self.attributes_of_interest.append("verified")

        os.makedirs(self.data_folder, exist_ok=True)

        to_download = [fragment for fragment in DATASET_OF_INTEREST if not self._fragment_downloaded(fragment)]
        logging.info(f"Following dataset fragments will be downloaded: {', '.join(to_download)}")

        for fragment in to_download:
            self._download_fragment(fragment)

        logging.info(f"Following dataset fragments will be loaded into memory: {', '.join(DATASET_OF_INTEREST)}")

        for fragment in DATASET_OF_INTEREST:
            self._load_data_fragment(fragment)

        self.apply_word_encoding()
        self.collect_X_and_y()
        
    def collect_X_and_y(self):
        self.X = [dato["X"] for dato in self.raw_data]
        self.y = [dato["y"] for dato in self.raw_data]

    def apply_word_encoding(self):
        """Train Word2Vec model and encode each token from data into a torch tensor"""
        corpus = [entry["reviewText"] for entry in self.raw_data]
        self.embedding_model = Word2Vec(sentences=corpus, min_count=1, vector_size=self.embedding_size, window=5)
        # Conert all the sentences
        for dato in tqdm(self.raw_data, desc=f"Embedding/Preparing dataset ..."):
            dato["X"] = self.tensor_factory(np.array([self.embedding_model.wv[token] for token in dato["reviewText"]]))
            if 'verified' in self.attributes_of_interest:
                # Add last bit (one or zero) to the end of the embeddings
                # TODO: Change this, this should be appended at the end of each entry of the sentence
                dato["X"] = torch.cat((dato["X"], self.tensor_factory([float(dato['verified'])]))).squeeze(0)
            dato["y"] = self.tensor_factory(dato['overall'])

    def _get_fragment_path(self, fragment):
        """Obtain the path to the potentially existing dataset fragment"""
        return os.path.join(self.data_folder, DATASETS[fragment])

    def _get_fragment_url(self, fragment):
        """Obtain URL to a dataset fragment"""
        return os.path.join(BASE_URL, DATASETS[fragment])

    def _download_fragment(self, fragment):
        """Download a single fragment gzip file"""
        file_destination_path = self._get_fragment_path(fragment)

        url_source = self._get_fragment_url(fragment)
        # Mock the human user
        headers = {
            "User-Agent": (
                "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1)"
                "AppleWebKit/537.36 (KHTML, like Gecko)"
                "Chrome/39.0.2171.95 Safari/537.36"
            )
        }

        data_request = requests.get(url_source, headers=headers, stream=True)
        total_download_size = int(data_request.headers.get("content-length", 0))
        tqdm_bar = tqdm(total=total_download_size, unit="iB", unit_scale=True, ncols=100)

        if data_request.status_code == 200:
            with open(file_destination_path, "wb") as f:
                for chunk in data_request.iter_content(chunk_size=16000):  # Why not?
                    tqdm_bar.update(len(chunk))
                    f.write(chunk)
            # TQDM 'hack' to stop printing the progress bar before the print statement
        else:
            # Request failed:
            logging.error(
                "Download failed, please try it once again or download data"
                + "manually from: "
                + url_source
                + " and save the json file here."
            )
            sys.exit(1)

    def _fragment_downloaded(self, fragment):
        """Is the fragment already downloaded?"""
        return os.path.isfile(os.path.join(self.data_folder, DATASETS[fragment]))

    def _is_data_complete(self, dato):
        """Return bool whether the data contains all required attributes"""
        return all(map(lambda x: x in dato, self.attributes_of_interest))

    def _load_data_fragment(self, fragment):
        """Load a single data fragment into the memory"""
        source_file = self._get_fragment_path(fragment)

        with gzip.open(source_file, "r") as file:
            for entry in tqdm(file.readlines(), desc=f"Reading {fragment} ..."):
                dato = json.loads(entry)
                if self._is_data_complete(dato):
                    # Create new entry only with data we care about
                    new_entry = {attr: dato[attr] for attr in self.attributes_of_interest}
                    # Let's tokenize the new entry text yet!
                    new_entry["reviewText"] = word_tokenize(new_entry["reviewText"])
                    self.raw_data.append(new_entry)
