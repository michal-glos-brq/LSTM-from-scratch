"""
This file implements base class for other datasets and  also a dummy datasets,
artificially generated for model behaviour verification.
"""

import torch


class EasyDataset(torch.utils.data.Dataset):
    def __init__(self, x, y, device, torch_type):
        # Select the correct tensor datatype
        torch_factory = torch.cuda if device == "cuda" else torch
        if torch.float16 == torch_type:
            self.torch_factory = torch_factory.HalfTensor
        elif torch.float32 == torch_type:
            self.torch_factory = torch_factory.FloatTensor
        elif torch.float64 == torch_type:
            self.torch_factory = torch_factory.DoubleTensor
        else:
            raise TypeError(f"Unknown type {torch_type}, only torch.float16/32/64 is supported.")

        self._X = x
        self._y = y

    def __len__(self):
        return len(self._y)

    def __getitem__(self, idx):
        return (self._X[idx], self._y[idx])

    @property
    def X(self):
        """Get the whola X data vector (padded)"""
        return torch.nn.utils.rnn.pad_sequence(self._X, batch_first=True)

    @property
    def y(self):
        """Obtain all labels as a tensor"""
        return self.torch_factory(self._y)

    def _padded_batch_loader(self, batch):
        """
        Return tuple of tensors (data, labels)
        Data will be padded with zeros
        """
        data, labels = [], []
        for dato, label in batch:
            data.append(dato)
            labels.append(label)
        return torch.nn.utils.rnn.pad_sequence(data, batch_first=True), self.torch_factory(labels)


class DatasetBase:
    """Base class for datasets to handle polymorphism"""

    def __init__(self, torch_type, device):
        """
        Initialize the base class

        Args:
            torch_type: Torch datatype (torch.float32 or else ...)
            device (str): Torch device cuda or cpu
        """
        self.torch_type, self.device = torch_type, device
        self.X_train, self.X_test, self.X_eval = None, None, None
        self.y_train, self.y_test, self.y_eval = None, None, None

    @property
    def entry_size(self):
        """Obtain the size of a single data entry vector"""
        return self.X_train.shape[2]

    @property
    def train_data(self):
        """Obtain the training data"""
        return EasyDataset(self.X_train, self.y_train, self.device, self.torch_type)

    @property
    def test_data(self):
        """Obtain the testing data"""
        return EasyDataset(self.X_test, self.y_test, self.device, self.torch_type)

    @property
    def eval_data(self):
        """Obtain the testing data"""
        return EasyDataset(self.X_eval, self.y_eval, self.device, self.torch_type)

    @staticmethod
    def define_argument_group(parser):
        """
        Define custom argument group for each dataset

        Args:
            parser (argparse.ArgumentParser): Argument parser object
        """
        raise NotImplementedError("Base class could not define it's argument group!")


class SummingIntDataset(DatasetBase):
    """A dataset with random integer sequences with y_gt only their respective sums"""

    name = "sum_int"

    def __init__(
        self,
        device: str = "cpu",
        torch_type: torch.dtype = torch.float32,
        min_val: int = 0,
        max_val: int = 16,
        seq_len: int = 64,
        vector_size: int = 32,
        train_data: int = 5000,
        test_data: int = 1000,
        eval_data: int = 1000,
    ):
        super().__init__(torch_type, device)
        # Create the training and eval Xs
        X_train = torch.randint(
            min_val,
            max_val,
            (train_data, seq_len, vector_size),
            device=self.device,
            dtype=self.torch_type,
            requires_grad=False,
        )
        X_test = torch.randint(
            min_val,
            max_val,
            (test_data, seq_len, vector_size),
            device=self.device,
            dtype=self.torch_type,
            requires_grad=False,
        )
        X_eval = torch.randint(
            min_val,
            max_val,
            (eval_data, seq_len, vector_size),
            device=self.device,
            dtype=self.torch_type,
            requires_grad=False,
        )
        # Compute adequate ground truths
        y_train = X_train.sum(dim=(1, 2))
        y_test = X_test.sum(dim=(1, 2))
        y_eval = X_eval.sum(dim=(1, 2))
        # Save the values
        self.X_train, self.X_test, self.X_eval = X_train, X_test, X_eval
        self.y_train, self.y_test, self.y_eval = y_train, y_test, y_eval

    @classmethod
    def instantiate_from_args(cls, args):
        """Instantiate self dataset object from CLI argparse parameters"""
        return cls(
            device=args.device,
            torch_type=getattr(torch, args.type),
            min_val=args.min_val,
            max_val=args.max_val,
            seq_len=args.sequence_len,
            vector_size=args.vector_len,
            train_data=args.train,
            test_data=args.test,
            eval_data=args.eval,
        )

    @staticmethod
    def define_argument_group(parser):
        """
        Define custom argument group for each dataset
        Weird arg. names are a must, because we have shared
        argument among the several dataset classes parsers

        Args:
            parser (argparse.ArgumentParser): Argument parser object
        """
        group = parser.add_argument_group(title="Dataset: SummingIntDataset")
        group.add_argument(
            "-min", "--min-val", type=int, default=0, help="Set the minimal value for seqence/vector element."
        )
        group.add_argument(
            "-max", "--max-val", type=int, default=10, help="Set the maximal value for seqence/vector element."
        )
        group.add_argument(
            "-sl", "--sequence-len", type=int, default=8, help="Set the length of the artificial sequences."
        )
        group.add_argument(
            "-vl", "--vector-len", type=int, default=4, help="Size of the vector as a single element of sequence."
        )
        group.add_argument(
            "-tr",
            "--train",
            type=int,
            default=10000,
            help="Specify how many training sequences shall be generated.",
        )
        group.add_argument(
            "-te", "--test", type=int, default=1000, help="Specify how many testing sequences shall be generated."
        )
        group.add_argument(
            "-ev", "--eval", type=int, default=1000, help="Specify how many eval sequences shall be generated."
        )
        return group


class SummingFloatDataset(DatasetBase):
    """A dataset with random integer sequences with y_gt only their respective sums"""

    name = "sum_float"

    def __init__(
        self,
        device: str = "cpu",
        torch_type: torch.dtype = torch.float32,
        seq_len: int = 64,
        vector_size: int = 32,
        train_data: int = 5000,
        test_data: int = 1000,
        eval_data: int = 1000,
    ):
        super().__init__(torch_type, device)
        # Create the training and eval Xs
        X_train = torch.rand(
            (train_data, seq_len, vector_size),
            device=self.device,
            dtype=self.torch_type,
            requires_grad=False,
        )
        X_test = torch.rand(
            (test_data, seq_len, vector_size),
            device=self.device,
            dtype=self.torch_type,
            requires_grad=False,
        )
        X_eval = torch.rand(
            (eval_data, seq_len, vector_size),
            device=self.device,
            dtype=self.torch_type,
            requires_grad=False,
        )
        # Compute adequate ground truths
        y_train = X_train.sum(dim=(1, 2))
        y_test = X_test.sum(dim=(1, 2))
        y_eval = X_eval.sum(dim=(1, 2))
        # Save the values
        self.X_train, self.X_test, self.X_eval = X_train, X_test, X_eval
        self.y_train, self.y_test, self.y_eval = y_train, y_test, y_eval

    @classmethod
    def instantiate_from_args(cls, args):
        """Instantiate this dataset and get it into data-loaded state from argparse Namespace object"""
        return cls(
            device=args.device,
            torch_type=getattr(torch, args.type),
            seq_len=args.sequence_len,
            vector_size=args.vector_len,
            train_data=args.train,
            test_data=args.test,
            eval_data=args.eval,
        )

    @staticmethod
    def define_argument_group(parser):
        """
        Define custom argument group for each dataset
        Weird arg. names are a must, because we have shared
        argument among the several dataset classes parsers

        Args:
            parser (argparse.ArgumentParser): Argument parser object
        """
        group = parser.add_argument_group(title="Dataset: SummingFloatDataset")
        group.add_argument(
            "-sl", "--sequence-len", type=int, default=8, help="Set the length of the artificial sequences."
        )
        group.add_argument(
            "-vl", "--vector-len", type=int, default=4, help="Size of the vector as a single element of sequence."
        )
        group.add_argument(
            "-tr",
            "--train",
            type=int,
            default=10000,
            help="Specify how many training sequences shall be generated.",
        )
        group.add_argument(
            "-te", "--test", type=int, default=1000, help="Specify how many testing sequences shall be generated."
        )
        group.add_argument(
            "-ev", "--eval", type=int, default=1000, help="Specify how many eval sequences shall be generated."
        )
