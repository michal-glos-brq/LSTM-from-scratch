import torch

from LSTM.utils import sigmoid_d


class Regressor:
    """
    Simple dense neural network to process LSTM features into a predicted value

    Manually programmed backpropagation results in possibl only one last batch being
    used for training, as previous batch process data would be overwritten by the new one
    """

    def __init__(self, input_size, hidden_size):
        self.W1 = torch.nn.init.xavier_uniform_(torch.empty((input_size, hidden_size), requires_grad=False))
        self.W2 = torch.nn.init.xavier_uniform_(torch.empty((hidden_size, 1), requires_grad=False))
        self.b1 = torch.zeros((hidden_size,), requires_grad=False)
        self.b2 = torch.zeros((1,), requires_grad=False)

    def forward(self, X, requires_grad=True):
        """
        Forward pass with 2 layered regressor

        X (torch.Tensor) : Input tensor of shape (batch_size, input_size)
        """
        hidden_output = torch.sigmoid(torch.matmul(X, self.W1) + self.b1)
        output = torch.matmul(hidden_output, self.W2) + self.b2

        if requires_grad:
            self.X = X
            self.hidden_output = hidden_output

        return output

    def backward(self, loss_d, lr):
        # loss_d is actually chained gradient, derivative of MSE and activation function, which is None
        hidden_layer_loss = torch.matmul(loss_d, self.W2.T)
        hidden_layer_chain_d = hidden_layer_loss * sigmoid_d(self.hidden_output)

        # Update weights and biases
        dW2 = torch.matmul(self.hidden_output.T, loss_d) * lr
        db2 = torch.sum(loss_d, dim=0) * lr  # Sum over batches

        # We use lr as limits because it's a faster way on how to apply the clamping after multiplying with learning rate
        self.W2 += torch.clip(dW2, min=-lr, max=lr)
        self.b2 += torch.clip(db2, min=-lr, max=lr)

        dW1 = torch.matmul(self.X.T, hidden_layer_chain_d) * lr
        db1 = torch.sum(hidden_layer_chain_d, dim=0) * lr  # Sum over batches
        self.W1 += torch.clip(dW1, min=-lr, max=lr)
        self.b1 += torch.clip(db1, min=-lr, max=lr)

        # Return chained derivatives for layers before the classifier
        out_chain_d = torch.matmul(hidden_layer_chain_d, self.W1.T)
        return out_chain_d


"""
This is dummy training example for the regressor, could be used later

r = Regressor(10,6)
y = torch.randint(0,10, (10000,))
X = torch.zeros((10000, 10))
X[torch.arange(10000), y] = 1

def train_vec(X, y, lr, step):
    losses, correct = [], []
    for i in range(0, len(X), step):
        x = X[i:i+step]
        _y = y[i:i+step].unsqueeze(1)
        y_pred = r.forward(x)
        loss = mse_loss(_y, y_pred)
        losses.append(loss)
        c = (torch.round(y_pred) == _y).sum() / len(y_pred)
        correct.append(c)
        loss_d = mse_loss_d(_y, y_pred)
        r.backward(loss_d, lr)
    print(f"l: {sum(losses) / len(losses)}; c: {100 * sum(correct) / len(correct)} %")

for i in range(100):
    train_vec(X, y, 0.03, 16)
"""
