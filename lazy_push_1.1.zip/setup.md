### How to setup venv for this project
This software works ideally in python3.8 virtual environment with requirements.txt installed.
Preffered way of installing and setting up the venv is:

```
conda create --name ZPJa python==3.8
conda activate ZPJa
pip install -r requirements.txt
```