from dataclasses import dataclass, field
from typing import List
import torch


# Derivative of the sigmoid function
def sigmoid_d(x):
    """Sigmoid derivative
    Parameters:
        x (torch.Tensor) : Input tensor
    """
    return x * (1 - x)


def tanh_d(x):
    """Tangens derivative
    Parameters:
        x (torch.Tensor) : Input tensor
    """
    return 1 - torch.tanh(x) ** 2


# Mean Squared Error loss function
def mse_loss(y_gt, y_pred):
    """Mean square error loss fucntion
    Parameters:
        y_gt (torch.Tensor) : ground truth tensor, (batch_size, 1)
        y_pred (torch.Tensor) : tensor predicted by the model, (batch_size, 1)
    """
    return ((y_gt - y_pred) ** 2).mean()


def mse_loss_d(y_gt, y_pred):
    """Derivative of mean square error loss fucntion
    Parameters:
        y_gt (torch.Tensor) : ground truth tensor, (batch_size, 1)
        y_pred (torch.Tensor) : tensor predicted by the model, (batch_size, 1)
    """
    return y_gt - y_pred


@dataclass
class LSTMGradParams:
    """This dataclass serves as a stack for LSTM data-flow for gradient computation"""

    stack_size: int = field(default_factory=lambda: 0)
    cat_inputs: List[torch.Tensor] = field(default_factory=list)
    cell_states_in: List[torch.Tensor] = field(default_factory=list)
    cell_states_out: List[torch.Tensor] = field(default_factory=list)
    input_gates: List[torch.Tensor] = field(default_factory=list)
    forget_gates: List[torch.Tensor] = field(default_factory=list)
    output_gates: List[torch.Tensor] = field(default_factory=list)
    candidate_gates: List[torch.Tensor] = field(default_factory=list)

    def add_entry(self, cat_input, cell_state_in, cell_state, input_gate, output_gate, forget_gate, candidate_gate):
        """Add a single timestep inference data on the stack"""
        self.cat_inputs.append(cat_input)
        self.cell_states_in.append(cell_state_in)
        self.cell_states_out.append(cell_state)
        self.input_gates.append(input_gate)
        self.output_gates.append(output_gate)
        self.forget_gates.append(forget_gate)
        self.candidate_gates.append(candidate_gate)
        self.stack_size += 1

    def clear(self):
        """Clear the whole stack"""
        self.stack_size = 0
        self.cat_inputs = []
        self.cell_states_in = []
        self.cell_states_out = []
        self.input_gates = []
        self.forget_gates = []
        self.output_gates = []
        self.candidate_gates = []


class LSTMGrads:
    """Class for cumulating weight and bias gradients for a LSTM cell"""

    def __init__(self, input_size, hidden_size, device="cpu", torch_type=torch.float32):
        """
        Args:
            input_size (int): Input vector len
            hidden_size (int): Hidden LSTM state (vector) size
        """
        # Initialize weight grads
        self.dWf = torch.zeros(
            (input_size + hidden_size, hidden_size), requires_grad=False, device=device, dtype=torch_type
        )
        self.dWi = torch.zeros(
            (input_size + hidden_size, hidden_size), requires_grad=False, device=device, dtype=torch_type
        )
        self.dWo = torch.zeros(
            (input_size + hidden_size, hidden_size), requires_grad=False, device=device, dtype=torch_type
        )
        self.dWc = torch.zeros(
            (input_size + hidden_size, hidden_size), requires_grad=False, device=device, dtype=torch_type
        )
        # Initialize bias grads
        self.dbf = torch.zeros((hidden_size,), requires_grad=False, device=device, dtype=torch_type)
        self.dbi = torch.zeros((hidden_size,), requires_grad=False, device=device, dtype=torch_type)
        self.dbo = torch.zeros((hidden_size,), requires_grad=False, device=device, dtype=torch_type)
        self.dbc = torch.zeros((hidden_size,), requires_grad=False, device=device, dtype=torch_type)

    def zero_grad(self):
        """Reset all gradients to zeros"""
        self.dWf[:] = 0
        self.dWi[:] = 0
        self.dWo[:] = 0
        self.dWc[:] = 0
        self.dbf[:] = 0
        self.dbi[:] = 0
        self.dbo[:] = 0
        self.dbc[:] = 0
