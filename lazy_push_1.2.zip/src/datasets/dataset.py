"""
This file implements base class for other datasets and  also a dummy datasets,
artificially generated for model behaviour verification.
"""

import torch


class DatasetBase:
    """Base class for datasets to handle polymorphism"""

    def __init__(self, torch_type, device):
        """
        Initialize the base class

        Args:
            torch_type: Torch datatype (torch.float32 or else ...)
            device (str): Torch device cuda or cpu
        """
        self.torch_type, self.device = torch_type, device
        self.X_train, self.X_test, self.X_eval = None, None, None
        self.y_train, self.y_test, self.y_eval = None, None, None

    @property
    def entry_size(self):
        """Obtain the size of a single data entry vector"""
        return len(self.X_train[0])

    @property
    def train_data(self):
        """Obtain the training data"""
        return self.X_train, self.y_train

    @property
    def test_data(self):
        """Obtain the testing data"""
        return self.X_test, self.y_test

    @property
    def eval_data(self):
        """Obtain the testing data"""
        return self.X_eval, self.y_eval


class SummingIntDataset(DatasetBase):
    """A dataset with random integer sequences with y_gt only their respective sums"""

    def __init__(
        self,
        device: str = "cpu",
        torch_type: torch.dtype = torch.float32,
        min_val: int = 0,
        max_val: int = 16,
        seq_len: int = 64,
        vector_size: int = 32,
        training_data: int = 5000,
        eval_data: int = 1000,
    ):
        super().__init__(torch_type, device)
        # Create the training and eval Xs
        X_train = torch.randint(
            min_val,
            max_val,
            (training_data, seq_len, vector_size),
            device=self.device,
            dtype=self.torch_type,
            requires_grad=False,
        )
        X_test = torch.randint(
            min_val,
            max_val,
            (eval_data, seq_len, vector_size),
            device=self.device,
            dtype=self.torch_type,
            requires_grad=False,
        )
        X_eval = torch.randint(
            min_val,
            max_val,
            (eval_data, seq_len, vector_size),
            device=self.device,
            dtype=self.torch_type,
            requires_grad=False,
        )
        # Compute adequate ground truths
        y_train = X_train.sum(dim=(1, 2))
        y_test = X_test.sum(dim=(1, 2))
        y_eval = X_eval.sum(dim=(1, 2))
        # Save the values
        self.X_train, self.X_test, self.X_eval = X_train, X_test, X_eval
        self.y_train, self.y_test, self.y_eval = y_train, y_test, y_eval


class SummingFloatDataset(DatasetBase):
    """A dataset with random integer sequences with y_gt only their respective sums"""

    def __init__(
        self,
        device: str = "cpu",
        torch_type: torch.dtype = torch.float32,
        seq_len: int = 64,
        vector_size: int = 32,
        training_data: int = 5000,
        eval_data: int = 1000,
    ):
        super().__init__(torch_type, device)
        # Create the training and eval Xs
        X_train = torch.rand(
            (training_data, seq_len, vector_size),
            device=self.device,
            dtype=self.torch_type,
            requires_grad=False,
        )
        X_test = torch.rand(
            (eval_data, seq_len, vector_size),
            device=self.device,
            dtype=self.torch_type,
            requires_grad=False,
        )
        X_eval = torch.rand(
            (eval_data, seq_len, vector_size),
            device=self.device,
            dtype=self.torch_type,
            requires_grad=False,
        )
        # Compute adequate ground truths
        y_train = X_train.sum(dim=(1, 2))
        y_test = X_test.sum(dim=(1, 2))
        y_eval = X_eval.sum(dim=(1, 2))
        # Save the values
        self.X_train, self.X_test, self.X_eval = X_train, X_test, X_eval
        self.y_train, self.y_test, self.y_eval = y_train, y_test, y_eval
