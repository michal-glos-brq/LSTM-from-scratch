import pickle

from tqdm import tqdm
import torch

from LSTM.LSTMCell import LSTMCell, BiLSTMCell
from LSTM.regressor import Regressor
from LSTM.utils import mse_loss, mse_loss_d


class LSTM:
    """
    This class implements a LSTM regressor model for regression tasks
    on variable-sized vactor sequences
    """

    modes = ["bag", "mean", "last"]

    def __init__(self, input_size, hidden_lstm, hidden_dense, mode, device="cpu", torch_type=torch.float32, bidirectional=False):
        """
        Initialize the LSTM regressor

        Args:
            input_size (int): Lenth of one element of data sequence
            hidden_lstm (int): Size of hidden state in the LSTM cell, also input size of the regressor
            hidden_dense (int): Size of the only hidden layer on the regressor
            device (str/torch.device): Device to work on (GPU/CPU) or rather (cpu/cuda)
            mode (str): How to process LSTM states from each step into the regressing model?
                        choices: bag - sum all, last - take the last, mean - average the states
            bidirectional (bool): Use bidirectional LSTM cell (with concat. as aggregating method)
        """
        if mode not in self.modes:
            raise ValueError(f"LSTM could not be initiated with mode={mode}")

        self.regressor = Regressor(hidden_lstm, hidden_dense, device=device, torch_type=torch_type)
        lstm_cell_cls = BiLSTMCell if bidirectional else LSTMCell
        self.lstm = lstm_cell_cls(input_size, hidden_lstm, device=device, torch_type=torch_type)
        self.device = device
        self.torch_type = torch_type
        self.mode = mode

    def divide_grads(self, grads, timesteps):
        """
        Divide gradients based on the method used to process LSTM hidden states

        Args:
            grads (torch.Tensor): Chained gradients from the regressor, will be divided based
                    on hidden state merging strategy (self.mode) into according timesteps in LSTM
                    shape: (batch_size, hidden_size)
            timesteps (int): Number of steps in time taken when LSTM was forwarded, also the len of last sequence
        """
        if self.mode.lower() == "bag" or self.mode.lower() == "mean":
            return grads.tile(timesteps, 1, 1)  # grads should always have 2 dims
        elif self.mode.lower() == "last":
            chained_grads = torch.zeros(
                (timesteps, *grads.shape), dtype=self.torch_type, device=self.device, requires_grad=False
            )
            # Store it as first, we would not need to revert it when backwarding through the sequence
            chained_grads[0] = grads
            return chained_grads.transpose(1, 0)

    def process_states(self, states):
        """
        Process LSTM hidden states to fit into regressor according to selected method

        Args:
            states (torch.Tensor): hidden states taken from LSTSM cell in each timestep (batch, sequence, hidden_size)
        Returns: torch.Tensor of shape (batch, hidden_size), the sequence is collapsed into homogenous vectors
        """
        if self.mode.lower() == "bag":
            return states.sum(dim=1)
        elif self.mode.lower() == "mean":
            return states.mean(dim=1)
        elif self.mode.lower() == "last":
            return states[:, -1, :]

    def forward(self, x, requires_grad=True):
        """
        Perform forward method on a data batch

        Args:
            x (torch.Tensor): A batch of input data of shape (batch_size, sequence_len, input_size)
        Returns: (torch.Tensor): a regressed values (estimation) of shape (batch_size, 1)
        """
        # Obtain the LSTM output
        lstm_hidden_states = self.lstm.forward(x, requires_grad=requires_grad)
        lstm_output = self.process_states(lstm_hidden_states)
        # Return the regressor output
        return self.regressor.forward(lstm_output, requires_grad=requires_grad)

    def backward(self, loss_d, lr):
        """
        Execute a single backward step (always after a single forward step was executed)

        Args:
            loss_d (torch.Tensor): Chained gradient from the objective function
                (chained directly to regressor output)
            lr (float): Learning rate
        Returns: None
        """
        # Train the regressor
        chained_d = self.regressor.backward(loss_d, lr)
        # Obtain gradients for LSTM and apply them
        last_sequence_len = self.lstm.stack_size  # Obtain the last sequence len
        chained_divided_d = self.divide_grads(chained_d, last_sequence_len)
        self.lstm.backward(chained_divided_d, lr)

    def train(self, X, y, X_test, y_test, lr, batch_size, epochs, steps_per_eval):
        """
        Train the model on given dataset

        Args:
            X (torch.Tensor): Input data, (dataset_len, sequence_len, element_vector_len)
            y (torch.Tensor): Ground truth with integer labels
            X_test (torch.Tensor): Input data for test purposes (dataset_len, sequence_len, element_vector_len)
            y_test (torch.Tensor): Ground truth with integer labels for test purposes
            lr (float): Learning rate
            batch_size (int): The size of batch for model to work with
            epochs (int): How many epochs to train the model for
            steps_per_eval (int): How many trainig steps to perform eval
        """
        # Normalize the learning rate
        lr = lr / batch_size
        steps_to_eval = steps_per_eval - 1
        test_success_rate = 0.0
        dataset_len = X.shape[0]
        shuffle_idxs = torch.cat([torch.randperm(dataset_len, device=self.device) for _ in range(epochs)])
        # How many entries missing to have exactly batches as requested? If any, add those in the dataset
        cap_batches_d = -shuffle_idxs.shape[0] % batch_size
        if cap_batches_d:
            shuffle_idxs = torch.cat((shuffle_idxs, torch.randperm(dataset_len, device=self.device)[:cap_batches_d]))

        # Now, we batched the whole dataset into one tensorfield, let's train the model!
        # This is a little confusing? Let's divide ground truth into (-1) batches, use the shape to
        # reshape the X but also use the X entry shape to not flatten the sequences
        shuffle_ids_iterator = shuffle_idxs.reshape(-1, batch_size)

        losses, eval_losses = [], []
        pbar = tqdm(shuffle_ids_iterator, desc="Training ...", ncols=80)

        for indices in pbar:
            # Get data
            x, y_gt = X[indices], y[indices]
            # Infere!
            y_pred = self.forward(x)

            # Make the GT a batch of one-element vectors and calculate the losses and gradients
            y_gt = y_gt.unsqueeze(1)
            loss = mse_loss(y_gt, y_pred)
            loss_d = mse_loss_d(y_gt, y_pred)
            losses.append(loss)
            # Do the backward step
            self.backward(loss_d, lr=lr)

            # Testing part
            if steps_to_eval == 0:
                steps_to_eval = steps_per_eval - 1
                test_success_rate, test_loss = self.eval(X_test, y_test)
                eval_losses.append(test_loss)
            else:
                steps_to_eval -= 1


            # Calculate and display the losses
            loss_avg = sum(losses[-64:]) / len(losses[-64:])
            pbar.set_description(
                (
                    f"Training ... (l: {loss_avg:.4f}; test: {test_success_rate * 100:.0f} % "
                    f"{eval_losses[-1] if eval_losses else float('inf'):.4f} l)"
                )
            )
        
        return losses, eval_losses

    def eval(self, X, y_gt):
        """
        Evaluate the model success rate on given dataset

        Args:
            X (torch.Tensor): Input data of shape (dataset_size, sequence_len, input_size)
            y_gt (torch.Tensor): Vector with ground truth "labels"
        """
        y_pred = self.forward(X, requires_grad=False).squeeze(1)
        success_rate = (torch.round(y_pred) == y_gt).sum() / y_pred.shape[0]
        return success_rate, mse_loss(y_pred, y_gt)

    def pickle(self, file_descriptor):
        """Pickle self into opened file descriptor"""
        pickle.dump(self, file_descriptor)

    @staticmethod
    def from_pickle(file_descriptor):
        """Open the file descriptor and load the pickled binary self"""
        return pickle.load(file_descriptor)
