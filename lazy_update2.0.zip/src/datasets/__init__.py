from datasets.dataset import SummingFloatDataset, SummingIntDataset

DATASETS = {
    SummingIntDataset.name: SummingIntDataset,
    SummingFloatDataset.name: SummingFloatDataset,
    # AmazonDS.name: AmazonDS,
    #
}
